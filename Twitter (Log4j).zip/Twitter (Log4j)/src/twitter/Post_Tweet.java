package twitter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;

		// TO Post a Message In Twitter

	public class Post_Tweet 
	
{
		Properties prop = new Properties();
	  
		@BeforeTest
	    public void first() throws Exception
	 {
			FileInputStream F=new FileInputStream("C:\\New folder1\\Twitter API\\twitter.properties");
			prop.load(F);
	 }
		
	
		@Test
		public void Post_Tweet() 
	 {
			RestAssured.baseURI=prop.getProperty("url");
			Response res=given().auth().oauth(prop.getProperty("Consumerkey"), prop.getProperty("ConsumerSecretkey"), prop.getProperty("Token"), prop.getProperty("TokenSecretkey")).
					queryParam("status"," Iam  learning   API   testing  using  Rest Assured  Java  #Qualitest ")
					.when().post("/update.json").then().extract().response();
		
			String response=res.asString();
			System.out.println(response);
		
			JsonPath js=new JsonPath(response);
			String id=js.get("id").toString();
			System.out.println(id);
		
			String text=js.get("text").toString();
			System.out.println(text);
	 }	
}
