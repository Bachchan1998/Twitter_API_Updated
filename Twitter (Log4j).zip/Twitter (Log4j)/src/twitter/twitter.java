package twitter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;

						//To get the Recent Tweet

	public class twitter 
	
{
		Properties prop = new Properties();
		
		@BeforeTest
		public void first() throws Exception
	 {
			FileInputStream F=new FileInputStream("C:\\New folder1\\Twitter API\\twitter.properties");
			prop.load(F);
	 }
		
		
		@Test
		public void get_Tweet() 
	 {
			RestAssured.baseURI=prop.getProperty("url");
			Response res=given().auth().oauth(prop.getProperty("Consumerkey"), prop.getProperty("ConsumerSecretkey"), prop.getProperty("Token"), prop.getProperty("TokenSecretkey")).
					queryParam("count","1")
					.when().get("/home_timeline.json?count=1").then().extract().response();
		
			String response=res.asString();
			System.out.println(response);
			
			JsonPath js=new JsonPath(response);
			String id=js.get("id").toString();
			System.out.println(id);
			
			String text=js.get("text").toString();
			System.out.println(text);		
	 }
	
}
