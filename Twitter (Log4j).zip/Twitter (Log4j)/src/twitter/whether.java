package twitter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;

	public class whether 
{
	
		Properties prop = new Properties();
		
		@BeforeTest
		public void first() throws Exception
	 {
			FileInputStream F=new FileInputStream("C:\\New folder1\\Twitter API\\twitter.properties");
			prop.load(F);
	 }
	
		
		@Test 
		public void listusers() 
	 {
			RestAssured.baseURI=prop.getProperty("weather");
			Response res=given().auth().oauth(prop.getProperty("Consumerkey"), prop.getProperty("ConsumerSecretkey"), prop.getProperty("Token"), prop.getProperty("TokenSecretkey")).
					param("q","bangalore weather").     
					when().get("/tweets.json").then().assertThat().statusCode(200).and().contentType(ContentType.JSON).extract().response();
		
			String response=res.asString();
			System.out.println(response);
     }
}